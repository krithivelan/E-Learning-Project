
  
     <div class="navbar navbar-default">
	 
		<div class="navbar-header">
					
			<div class="navbar-brand" class="nav_title"><a href="tutor_home.php"><strong>E-Learning</strong></a>
				
			</div>						
					<ol>
						<li ><a href="u_c_m.php">Upload Course Materials</a></li>
						<li ><a href="t_quiz.php">Add Quiz</a></li>
						<li ><a href="t_ann.php">Announcements</a></li>
						<li ><a href="t_pro.php">Profile</a></li>
					</ol>
		</div>
			
		<li class="login_disp"><a href="logout.php">Logout</a></li>
				
				
	</div>
	
	
	<br>