
  <html>

	<head>
		<title>E-learning Login</title>
		<link rel="stylesheet" href="https://bootswatch.com/flatly/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="styles.css">
		<link rel="stylesheet" type="text/css" href="style/f.css">
	</head>

	<body>
		<script src="js/bootstrap.min.css"></script>