
 <?php 

	session_start();
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['tname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}

?>
  
   <?php include('header.php'); ?>
   <?php include('tutor_login_nav.php'); ?>
   
   <div class="container">
		<div>
	
		<!--
		
		<form action="tutor_home.php" method="post" enctype="multipart/form-data">
			<input type="file" name="file" />
			<br>
			<button type="submit" name="btn-upload">upload</button>
		</form>
	
		-->
		
		<div id="header">
			
				</div>
					<div id="body">
					
					
					 <form action="u_c_m.php" method="post" enctype="multipart/form-data">
						
								<div class="form-group">
									<label>Choose your Course</label>
									
									<select name="pcourse">
										
											<option value="C">C</option>
											<option value="C++">C++</option>
						
									</select>
								
								</div>
							<br>
							
							
								<div class="form-group">
								<label >Heading</label>
									<input type="text" name="phead" placeholder="Enter the Heading" class="form-control">
								</div>
							
							<br>
								
								<div class="form-group">	
								<label >Content</label>
									<textarea name="pbody" placeholder="Enter the Content" class="form-control"></textarea>
								</div>
							
							<br>
							
								<input type="file" name="file" />
							
							<br>
							
								<button type="submit" name="btn-upload">upload</button>
								
					 </form>
						<br /><br />
						
				</div>
			<div id="footer">
			
		</div>
					
		
		
		
		<?php
		
			
			
			
			
			
		
			if(isset($_POST['btn-upload']))
			{    
				$u_head = $_POST['phead'];
				$u_body = $_POST['pbody'];
				$u_course = $_POST['pcourse'];
				
				
				 if($u_body!="" && $u_head!="" && $u_course!="" )
				{	 
					if($u_course=="C")
					{
						if(!isset($file))
						{
						 $file = $_FILES['file']['name'];
						 $file_loc = $_FILES['file']['tmp_name'];
						 $file_size = $_FILES['file']['size'];
						 $file_type = $_FILES['file']['type'];
						 $folder="uploads/";
						 
						 move_uploaded_file($file_loc,$folder.$file);
						 $sql="INSERT INTO c_table(course,heading,content,file) VALUES('$u_course','$u_head','$u_body','$file')";
						 mysqli_query($conn,$sql); 
						}
						else
						{
							 echo "<h3 class='btn btn-danger'> Please Select the File ! <h4>";
						}
					}
					else if($u_course=="C++")
					{
						if(!isset($file))
						{
						 $file = $_FILES['file']['name'];
						 $file_loc = $_FILES['file']['tmp_name'];
						 $file_size = $_FILES['file']['size'];
						 $file_type = $_FILES['file']['type'];
						 $folder="uploads/";
						 
						 move_uploaded_file($file_loc,$folder.$file);
						 $sql="INSERT INTO cplus_table(course,heading,content,file) VALUES('$u_course','$u_head','$u_body','$file')";
						 mysqli_query($conn,$sql); 
						}
						else
						{
							 echo "<h3 class='btn btn-danger'> Please Select the File ! <h4>";
						}
						
					}
					else
					{
						echo "<h3 class='btn btn-danger'> Please Select the Course ! ! <h4>";
					}
				
					
				}
				 else
				 {
					 echo "<h3 class='btn btn-danger'> Please Fill in all the fields <h4><br>";
				 }
			}
			else if(!isset($u_course))
			{
				"<h3 class='btn btn-alert'> Upload the Course materials ! <h4>";
				$u_head = "";
				$u_body = "";
				$u_course = "";
			}
			?>
			
			<?php
					if($u_course=="C")
					{
						$sql="SELECT * FROM c_table";
						$result_set=mysqli_query($conn,$sql);
					}
					
					else if($u_course=="C++") 
					{
						$sql="SELECT * FROM cplus_table";
						$result_set=mysqli_query($conn,$sql);
					}
					else
					{
						$sql="SELECT * FROM c_table";
						$result_set=mysqli_query($conn,$sql);
					}
			
			
			 while($row=mysqli_fetch_assoc($result_set))
			 {
				 //print_r($row);
			?>
					
					<div class="panel panel-default">
					
						  <!-- Default panel contents -->
						  <div class="panel-heading"><?php echo $row['heading']; ?></div>
						  <div class="panel-body">
							<p><?php echo $row['content']; ?></p>
						  
								<br>
								
								<!-- List group -->
							  <ul class="list-group">
								<div class="list-group" ><strong><?php echo "File Name : ";echo $row['file']; ?></strong></div>
								
								
								<a href="uploads/<?php echo $row['file'] ?>" target="_blank" class="btn btn-success" >Download</a>
								
							  </ul>
						  </div>
					</div>
					
					<br>
			
			<?php	 }	 ?>
					
		
		</div>
   </div>
   
   <?php include('footer.php'); ?>