
  <?php 

	session_start();
	
	include('db3_config.php');
	
	
	//$table_name = $_SESSION['table_name'];
	
	$sname = $_SESSION['sname'];
	$susername = $_SESSION['susername'];
	$sid = $_SESSION['sid'];
	$scourse = $_SESSION['scourse'];
	
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}
	
	/*
	if(!isset($_POST['sqnext']))
	{
		$_SESSION['score']= 0;
		$number=1;
		$_SESSION['q_no']=1;
	}
	*/

?>
  
   <?php include('header.php'); ?>
   <?php include('student_login_nav.php'); ?>
   <?php //include('timer.php'); ?>
   
   <div class="content">
   <div class="container">
   
  
  <?php //echo $table_name; ?>
  
	<?php
			
			
			$number = $_GET['n'];
			
			//echo "number ---$number";
				
				
			
			$sql="SELECT * FROM quiz1 WHERE course='$scourse' AND question_no='$number' ";
			
			$result_set=mysqli_query($conn_new_db,$sql);
			
			$row=mysqli_fetch_assoc($result_set);
			
			//$user_ans = $_GET['opa'];	
				$ques = $row['question'];
				$_SESSION['in_ques'] = $ques;
				$ans = $row['ans'];
				$question_no = $row['question_no'];
				$course = $row['course'];
				$next = $question_no + 1;
			
			    //echo $ques;
				//print_r($row);
				
				
			  
		
	?>
					
					<form method="get" action="sc_quiz.php">
				
						   <a href="#" class="list-group-item list-group-item-info"><h4 ><?php echo $ques; ?></h4></a><br>
							
							<div  class="list-group">
							
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="A">
											<?php echo $row['opa']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="B">
											<?php echo $row['opb']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="C">
											<?php echo $row['opc']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="D">
											<?php echo $row['opd']; ?>
								</a><br>
								
							</div>
							
						
						<br>
				
				<button type="submit" class="btn btn-success" name="sqnext">Next</button>
			
			
					 
					 
					 
			 
				 <?php
						
				 
					if(isset($_GET['sqnext']))
					{
						$user_ans = $_GET["opa"];
						$_SESSION['ques'] = $row['question'];
							
							if(isset($_GET['opa']))
							{
								$ques = $_SESSION['ques'];
								$query = "SELECT * FROM quiz1";
								$sql="INSERT INTO `u_quiz` ( `ques`, `ans`, `name`, `username`, `course`) VALUES ('$ques','$user_ans','$sname','$susername','$scourse')";
								if(mysqli_query($conn_new_db,$sql))
								{
									echo "Answer Saved";
									
									$res = mysqli_query($conn_new_db,$query);
									$row=mysqli_fetch_assoc($res);
									
									if(isset($row))
									{
										//print_r($row);
										//$a=$a-1;
										
										
										
										
										/*
										echo $row['username'];
										echo "<br>";
										echo $susername;
										echo "<br>";
										*/
										
										echo "<br>";
										echo $row['ans'];
										echo "<br>";
										echo $user_ans;
										
										echo "<br>";
										echo $row['question_no'];
										echo "<br>";
										echo $_SESSION['check_q_no'];
										
										if( $row['ans']==$user_ans )
										{
											$_SESSION['check_q_no']++;
											
											$_SESSION['score']++;
											
											
										}
										
										if( $_SESSION['q_no'] == 4 )
										{
											
											if( $row['ans']==$user_ans )
											{
																							
												$_SESSION['score']++;
												
												$s  = $_SESSION['score'];
												
												$sql="INSERT INTO `score` ( `score`, `name`, `username`, `course`) VALUES 
													('$s','$sname','$susername','$scourse')";
													
													if(mysqli_query($conn_new_db,$sql))
													{
														echo "Your Score is Saved";
																
													}
												
											
											}
											
											header('Location: '.ROOT_URL.'shome.php');
											
											exit();
										}
										else
										{
											
											$_SESSION['q_no'] ++;
																						
											header('Location: '.ROOT_URL.'sc_quiz.php?n='.$_SESSION['q_no']);
											
										}
										
									}
									
								}
								
							}
							else
							{
								echo "<h4 class='btn btn-danger'>Choose the Answer</h4>";
							}
					}
					else
					{
						$user_ans ="";
					}
				
			
			 ?>
			
			</form>
		
		
		
			
	</div>
   </div>
   


    <?php include('footer.php'); ?>
	