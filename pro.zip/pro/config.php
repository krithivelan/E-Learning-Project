 
  <?php 
  
	  define('ROOT_URL','http://localhost/pro/');
	  define('DB_HOST','localhost');
	  define('DB_USER','root');
	  define('DB_PASS','dbpass');
	  define('DB_NAME','elearning');
  
 
  ?>