 
  
   
    <?php 
	  
			session_start();
			
			$name = $_SESSION['tname'];
			
			
			include('config.php');
			include('db.php');
			include('db2_config.php');
			
			if(!isset($_SESSION['tname']))
			{
				header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
			}

	?>	
		  
	<?php include('header.php'); ?>
    <?php include('tutor_login_nav.php'); ?>
   
    <div class="container">
	
		<form method="post" action="t_ann.php"  >
		
			<div class="form-group">
				<label >Username</label>
				<input type="text" name="ausername" placeholder="Enter your name " class="form-control">
			</div><br>
			
			<div class="form-group">
				<label>Choose your Course</label>
									
					<select name="acourse">
										
						<option value="C">C</option>
						<option value="C++">C++</option>
						
					</select>
								
			</div>
			<br>
			
			<div class="form-group">
				<label >Email</label>
				<input type="email" name="aemail" placeholder="Enter the Heading" class="form-control">
			</div><br>
			
			<div class="form-group">	
				<label >Announcement</label>
				<textarea name="ann" placeholder="Enter the Content" class="form-control"></textarea>
			</div>
			
			<button type="submit" name="b_ann">Make Announcement</button>
			
		</form>
		
		<?php
		
			if(isset($_POST['b_ann']))
			{
				$ann_name = $_POST['ausername'];
				$ann_course = $_POST['acourse'];
				$ann_email = $_POST['aemail'];
				$ann = $_POST['ann'];
				if($ann_name!="" && $ann_course!="" && $ann_email!="" && $ann!="")
				{
					
					if($name==$ann_name )
					{
						$query = "INSERT INTO t_ann(name,course,email,ann) VALUES('$ann_name','$ann_course','$ann_email','$ann')";
						if(mysqli_query($conn,$query))
						{
							echo "<h3 class='btn btn-success'> Your Announcement has been posted ! <h4>";
						}
					}
					else
					{
						echo "<h3 class='btn btn-danger'> Please Fill in correct Username and Email ID ! <h4>";
					}
				}
				else
				{
					echo "<h3 class='btn btn-danger'> Please Fill in All the Fields ! <h4>";
				}
			}
		
		?>
	
	</div>
	
	<?php include('footer.php'); ?>