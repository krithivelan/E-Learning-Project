

<?php
	
	include('config.php');
	include('db.php');
	
	$login_msg='';
	
	if(isset( $_POST['tregister']))
	{
	
		$var_tname = $_POST['tname'];
		$var_tusername = $_POST['tusername'];
		$var_temail = $_POST['temail'];
		$var_tpassword = $_POST['tpassword'];
		$var_trepassword = $_POST['trepassword'];
		$var_tdes = $_POST['tdes'];
		$var_tdesname = $_POST['tdesname'];
		$var_tdesadd = $_POST['tdesadd'];
		$var_tdesid = $_POST['tdesid'];
		$var_tphno = $_POST['tphno'];
		
		if(!empty($var_tname)&&!empty($var_tusername)&&!empty($var_temail)&&!empty($var_tpassword)&&!empty($var_tdes)&&!empty($var_tdesname)&&!empty($var_tdesadd)&&!empty($var_tdesid)&&!empty($var_tphno))
		{	
			if($var_tpassword==$var_trepassword)
			{				
				if( strlen($var_tphno)== 10 )
				{
				
					$query = "INSERT INTO tutor_register(tname,tusername,temail,
					tpassword,tdes,tdesname,
					tdesadd,tdesid,tphno) VALUES('$var_tname','$var_tusername','$var_temail','$var_tpassword','$var_tdes','$var_tdesname','$var_tdesadd','$var_tdesid','$var_tphno')";
					
					if(mysqli_query($conn,$query))
					{
						header('Location: '.ROOT_URL.'login.php?msg=<p class="alert alert-success">Successfully Registered. Login to continue...</p>');
						
					}
					else
					{
						echo 'ERROR-------------'.mysqli_error($conn);
					}				
				}
				else
				{
					$login_msg="Enter Correct Phone No ! ";
					$login_msg_class="alert-danger";
				}
				
			}
			
			else
			{				
				$login_msg = " Password and Confirm password dosen't match ! ";
				$login_msg_class = "alert-danger";		
			}
						
		}
		
		else
		{
			$login_msg = " Fill in all the fields ! ";
			$login_msg_class = "alert-danger";
			
		}	
	}
	
?>



<?php include('header.php'); ?>
<?php include('home_nav.php'); ?>
  
  <div class="container">
  
			<?php if(  $login_msg != ''  ): ?>
			
				<div class="alert <?php echo $login_msg_class; ?>"><?php echo $login_msg; ?></div>
				
			<?php endif; ?>
  
	<h1 class="login_heading">Tutor Registration Form</h1>
			
			
			
				<form action="tutor_register.php" method="POST">
					<div class="form-group">
						<label>Tutor's Name</label>
						<input type="text" name="tname" placeholder="Enter your Username" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Tutor's User Name</label>
						<input type="text" name="tusername" placeholder="Enter your User Name" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Tutor's Email</label>
						<input type="email" name="temail" placeholder="Enter your Email" class="form-control">
					</div>
					
					<br>
					
									
					
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="tpassword" placeholder="Enter your Password" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Re-Enter Password</label>
						<input type="password" name="trepassword" placeholder="Re-Enter your Password" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Choose Your Designation</label>
							<select name="tdes">
								
									<option value="Tutor">Tutor</option>
									
								
							</select>
					</div>
					<br>
					
					<div class="form-group">
						<label>Working In (Name of the Workspace) :</label>
						<input type="text" name="tdesname" placeholder="Enter your Company name" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Address of Workspace :</label>
						<input type="text" name="tdesadd" placeholder="Address of Workspace " class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>ID of Tutor:</label>
						<input type="text" name="tdesid" placeholder="Enter your id" class="form-control">
					</div>
					
					<br>

					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" name="tphno" placeholder="Enter your Phone number" class="form-control">
					</div>
					
					<br>
					
					<p>By registering you accept our terms and conditions</p>
					
					<br>
					
					<div class="form-group">
						<input type="submit" value="Register" name="tregister" class="btn btn-primary">
					</div>
					<br><br><br><br>
						
				</form> 
  </div>
  
  
  <?php include('footer.php'); ?>