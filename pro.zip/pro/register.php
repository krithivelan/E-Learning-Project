
<?php include('header.php'); ?>
<?php include('home_nav.php'); ?>
  
  <div class="container">
  
	<div class="reg_class" >
		<p><a href="s_reg.php">Student Registration</a></p>
	</div>
	
	<div class="reg_class" >
		<p><a href="tutor_register.php">Tutor Registration</a></p>
	</div>
	
	
  </div>
  
  
  <?php include('footer.php'); ?>