
	<?php 
			
			session_start();
			
			$name = $_SESSION['tname'];
			$new_table = $_SESSION['new_table'];
			$total_qa = $_SESSION['total_qa'];
			$qcourse = $_SESSION['qcourse'];
			
			
			include('config.php');
			include('db.php');
			include('db2_config.php');
			
			if(!isset($_SESSION['tname']))
			{
				header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
			}
		
	?>	
		  
	<?php include('header.php'); ?>
    <?php include('tutor_login_nav.php'); ?>
	
	<div class="container" >
	
	
		
				
		<form  action="qc_quiz.php" method="post">
				
			<div class="form-group">
				<label >Question</label>
				<input type="text" name="ques" placeholder="Enter the Question " class="form-control">
			</div>
				
			<div class="form-group">
				<label >Option A</label>
				<input type="text" name="opa" placeholder="Enter Option A " class="form-control">
			</div>
				
			<div class="form-group">
				<label >Option B</label>
				<input type="text" name="opb" placeholder="Enter Option B  " class="form-control">
			</div>
				
			<div class="form-group">
				<label >Option C</label>
				<input type="text" name="opc" placeholder="Enter Option C  " class="form-control">
			</div>
				
			<div class="form-group">
				<label >Option D</label>
				<input type="text" name="opd" placeholder="Enter Option D  " class="form-control">
			</div>
					
			<div class="form-group">
				<label >Answer ( Enter the Answer in Upper case such as A/B/C/D ) : </label>
				<input type="text" name="ans" placeholder="Enter the Answer " class="form-control">
			</div>
			
			<button type="submit" name="qc_submit">Add a Question</button>
					
		</form>
	
	<?php
		
		
		if(isset($_POST['qc_submit']))
		{
			$ques = $_POST['ques'];
			$opa = $_POST['opa'];
			$opb = $_POST['opb'];
			$opc = $_POST['opc'];
			$opd = $_POST['opd'];
			$ans = $_POST['ans'];
			
			if( $ques!="" && $opa!="" && $opb!="" && $opc!="" && $opd!=""&& $ans!="" )
			{
				$query = "INSERT INTO $new_table(question,opa,opb,opc,opd,ans,course) VALUES('$ques','$opa','$opb','$opc','$opd','$ans','$qcourse')";
				if(mysqli_query($conn,$query))
				{
					echo "<h4 class='btn btn-success'> Success ! <h4><br>";	
				}
			}
			else
			{
				echo "<h4 class='btn btn-danger'>fill in all the fields</h4>";
			}
			
		}
		
	?>
	
	
	</div>
	
	
	
	<?php include('footer.php'); ?>
	

				
