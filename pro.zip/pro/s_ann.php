
 <?php 

	session_start();
	
	$sname = $_SESSION['sname'];
	$susername = $_SESSION['susername'];
	$sid = $_SESSION['sid'];
	$scourse = $_SESSION['scourse'];
	
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}

?>
  
   <?php include('header.php'); ?>
   <?php include('student_login_nav.php'); ?>
   
	    <div class="container">
			
			<?php
					if($scourse=="C")
					{
						$sql="SELECT * FROM t_ann WHERE course='$scourse' ";
						$result_set=mysqli_query($conn,$sql);
					}
					
					else if($scourse=="C++") 
					{
						$sql="SELECT * FROM t_ann WHERE course='$scourse' ";
						$result_set=mysqli_query($conn,$sql);
					}
								
			 while($row=mysqli_fetch_assoc($result_set))
			 {
				 //print_r($row);
			?>
					
					<div class="panel panel-default">
					
						  <!-- Default panel contents -->
						  <div class="panel-heading"><strong>
						  
						  <?php echo $row['course']; ?>
						  - Programming Course Announcement</strong></div>
						  
						  
						  <div class="panel-body">
						  <p>Posted at : <?php echo $row['time']; ?></p>
						  
						  <br><br>
								
								<!-- List group -->
							    <ul class="list-group">
								<div class="list-group" ><strong><?php echo $row['ann']; ?></strong></div>							
							    </ul>
						  </div>
						  
						  
					</div>
					
					<br>
			
			<?php	 }	 ?>
	   
	    </div>
   
   <?php include('footer.php'); ?>