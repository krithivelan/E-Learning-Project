<?php 

	session_start();
	
	include('db3_config.php');
	
	
	//$table_name = $_SESSION['table_name'];
	
	$sname = $_SESSION['sname'];
	$susername = $_SESSION['susername'];
	$sid = $_SESSION['sid'];
	$scourse = $_SESSION['scourse'];
	
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}
	
	

?>