
  <?php 

	session_start();
	
	include('db3_config.php');
	$sname = $_SESSION['sname'];
	$susername = $_SESSION['susername'];
	$sid = $_SESSION['sid'];
	$scourse = $_SESSION['scourse'];
	$_SESSION['q_no'] = 1;
	$_SESSION['score']=0;
	$_SESSION['check_q_no']=1;
	
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}

?>
  
   <?php include('header.php'); ?>
   <?php include('student_login_nav.php'); ?>
   <?php //include('timer.php'); ?>
   
    <div class="content">
	<div class="container">

		<form class="form-signin well" method="post" action="s_quiz.php">	
			<input type="submit" value="Show the Available Quizzes!" name="start-btn" class="btn btn-success">
		</form>
			
	</div>
	</div>
		
	<?php
	
		if(isset($_POST['start-btn']))
		{
				
			$sql = "SHOW TABLES";
			$result = mysqli_query($conn_new_db,$sql);
			$tables = mysqli_fetch_assoc($result);
				
			foreach($tables as $tmp)
			{
				//print_r($tmp);
			?>	
	<div class="content">
	<div class="container">
		<div class="panel panel-default">
			<div class="panel-heading">Select the Required Quiz<br></div>
			
				
				<table class="table table-default" width="100%" >
								
							<tr >
									<td class="class_files"><strong>Table Name</strong></td>
									
									<td class="class_files"> 
										<?php echo "$tmp <br>"; ?>
									</td>
									
									<td class="class_files" > 
										<a href="sc_quiz.php?n=1">
													
										<input type="submit" class="btn btn-warning" name="fetcourse" value="Attempt Quiz">
										</a>
									</td>
							</tr>
				</table>				
			<?php }	} ?>
			
			
		<?php
			
		?>
		</div>
			
	
	</div>
	</div>
     
    <?php include('footer.php'); ?>
	