<?php include('header.php'); ?>
  <?php include('home_nav.php'); ?>
  
  <div class="container">
  
	<h1 class="login_heading">Contact Us</h1>
	
		<form method="POST" action="contactinfo.php" >
		
		<div class="form-group">
			<label>Name</label>
			<input type="text" name="cname" placeholder="enter your name" class="form-control">
		</div><br>
		
		<div class="form-group">
			<label>Email</label>
			<input type="email" name="cemail" placeholder="enter your name" class="form-control">
		<div><br>
		
		<div class="form-group">
			<label>Message</label>
			<textarea  name="cmsg" class="form-control"></textarea>
		<div><br>
		
		<div>
			<input type="submit" value="Submit" name="csubmit" class="btn btn-primary">
		<div>
		
		</form>
  
  </div>
  
  <?php include('footer.php'); ?>