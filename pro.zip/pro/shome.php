
<?php 

	session_start();
	
	include('db3_config.php');
	
	//$_SESSION['score'];
	include('config.php');
	include('db.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}

?>
  
   <?php include('header.php'); ?>
   <?php include('student_login_nav.php'); ?>
   
   <div class="container">
   <h4 style="
		float:right;
		background-color:MediumSeaGreen;
		padding:15px;
		color:white;
		display:inline-block;
		text-align:center;"
			
	>Welcome <?php echo $_SESSION['sname']; ?></h4>
		<div>
		
		<?php if(isset($_SESSION['score'])): ?>
			<h1 class="btn btn-info">YOUR SCORE : <?php echo $_SESSION['score'];?> / 4</h1>
		<?php endif; ?>
		
		<h2>Your Past Scores</h2>
		
		<?php
			
			
			$sql="SELECT * FROM score";
			 $result_set=mysqli_query($conn_new_db,$sql);
			 while($row=mysqli_fetch_assoc($result_set))
			{
				 
	?>
		
					<div class="row">
					  <div class="col-sm-6 col-md-4">
						<div class="thumbnail">
						  <div class="glyphicon glyphicon-file" >
						  <div class="caption">
							<h3>Your Score : <?php echo $row['score'] ?> / 4</h3>
							
							<p> Name : <?php echo $row['name']; ?> </p>
							<p> Course : <?php echo $row['course']; ?> </p>
							<p> Created At : <?php echo $row['time']; ?> </p>
							<p> Wrong Answers : <?php $s = $row['score'];
												
														$sn = 4 - $s;
														echo $sn;
												
												?> </p>
							
						  </div>
						  </div>
						</div>
					  </div>
					</div>
							
					
					<br>
					
	<?php   }    ?>
		
		</div>
   </div>
   
   <?php include('footer.php'); ?>