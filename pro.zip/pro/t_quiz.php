 
  
   <?php 
	  
			session_start();
			
			$name = $_SESSION['tname'];
			
			include('db3_config.php');
			include('config.php');
			include('db.php');
			include('db2_config.php');
			
			if(!isset($_SESSION['tname']))
			{
				header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
			}
		
	?>	
		  
	<?php include('header.php'); ?>
    <?php include('tutor_login_nav.php'); ?>
	
		<div class="container" class="jumbotron">
		
			<form method="post" action="t_quiz.php">
			
				<div class="form-group">
				<label >Name of the Quiz : </label>
				<input type="text" name="quizname" placeholder="Enter the Quiz Name " class="form-control">
				</div><br>
				
				<div class="form-group">
				<label >Total no of Questions : </label>
				<input type="number" name="total_q" placeholder="Enter the Total no of Questions " class="form-control">
				</div><br>
				
				<div class="form-group">
					<label>Choose your Course</label>			
					<select name="qcourse">			
						<option value="C">C</option>
						<option value="C++">C++</option>
					</select>	
				</div><br>
				
				<button type="submit" name="qc_button" >Create new Quiz</button><br>
				
				<?php
				
					if(isset($_POST['qc_button']))
					{
						$new_table = $_POST['quizname']; 
						$qcourse = $_POST['qcourse']; 
						if($new_table!="" && $qcourse!="")
						{
							$query = 'CREATE TABLE `elearning`.`'.$new_table.'` (

								`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
								`question` TEXT NOT NULL ,
								`opa` TEXT NOT NULL ,
								`opb` TEXT NOT NULL ,
								`opc` TEXT NOT NULL ,
								`opd` TEXT NOT NULL ,
								`ans` VARCHAR( 255 ) NOT NULL,
								`course` TEXT NOT NULL,
								`time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP	

							) ; ';
							if(mysqli_query($conn,$query))
							{
								echo "<h3 class='btn btn-success'> Success. Table created ! <h4>";
								$_SESSION['new_table']= $new_table;
								$_SESSION['total_qa'] = $total_qa;
								$_SESSION['qcourse'] = $qcourse;
								header('location: '.ROOT_URL.'qc_quiz.php');
								
							}
						}
						else
						{
							echo "<h3 class='btn btn-danger'> Please Fill in all the Fields ! <h4>";
						}
					}
				
				?>
				
			
			</form>
			
		</div>
	
	<?php include('footer.php'); ?>