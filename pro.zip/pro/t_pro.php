
  <?php 
			
			session_start();
			
			$username = $_SESSION['tname'];
		
			include('config.php');
			include('db.php');
			include('db2_config.php');
			
			if(!isset($_SESSION['tname']))
			{
				header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
			}
		
	?>	
		  
	<?php include('header.php'); ?>
    <?php include('tutor_login_nav.php'); ?>
	
	<div class="container" >
	
	
	
	<h2 class="login_heading"><?php echo "$username's ";?>Profile</h2><br>
			
				<?php
							 
						//$sql="SELECT id,tname,tusername,temail,tdes,tdesname,tdesadd,tphno,date FROM tutor_register ";
						
						$sql="SELECT * FROM tutor_register ";
							 
						$result_set=mysqli_query($conn,$sql);
						while($row=mysqli_fetch_assoc($result_set))
							 {
								 
						//print_r($row);
				?>
						<div class="list-group">
							<h4 class="list-group-item " class="btn btn-warning">  <label><strong> Name </strong></label></h4>
							<p class="list-group-item">  <?php echo $row['tname']; ?></p><br>
							
							<h4 class="list-group-item ">  <label><strong> Username </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['tusername']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Email </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['temail']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Designation </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['tdes']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Name of Workspace </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['tdesname']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Address of Workspace </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['tdesadd']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Phone No. </strong> </label></h4>
						    <div class="list-group-item">  <?php echo $row['tphno']; ?></div><br>
							
							<h4 class="list-group-item ">  <label><strong> Profile Created At </strong> </label></h4>
							<div class="list-group-item">  <?php echo $row['date']; ?></div><br>
						</div>	
							
						
				<?php }	 ?>
		
		<!--
		
		<input type="file" name="file" />
			
		<br>
		
		<button type="submit" name="btn-upload"> Upload your Profile Picture </button>
		
		-->
		
	
	</div>
	
	<?php include('footer.php'); ?>
	