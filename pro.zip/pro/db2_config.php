
	<?php
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpass = "dbpass";
		$dbname = "dbtuts";
		
		

		   $conn_db = mysqli_connect( $dbhost , $dbuser , $dbpass , $dbname );
			
			if(mysqli_connect_errno())
			{
				echo 'failed to connect-----'.mysqli_connect_errno();
			}
			else
			{
				//echo "connected<br>";
			}
		  
		 
		
	?>