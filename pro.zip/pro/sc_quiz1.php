<?php 

	session_start();
	
	include('db3_config.php');
	$sname = $_SESSION['sname'];
	$susername = $_SESSION['susername'];
	$sid = $_SESSION['sid'];
	$scourse = $_SESSION['scourse'];
	
	
	include('config.php');
	include('db.php');
	include('db2_config.php');
	
	if(!isset($_SESSION['sname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}
	
	
		if(isset($_GET['sqnext']))
		{
		}	
			//$num = $_GET['n'];
			
			
			
			$sql=" SELECT * FROM quiz1 WHERE course='$scourse'  ; ";
			
			$result_set=mysqli_query($conn_new_db,$sql);
			
			$row = mysqli_fetch_assoc($result_set);
			
			echo mysqli_num_fields($row);		     
		
	

?>

<?php include('header.php'); ?>
   <?php include('student_login_nav.php'); ?>
   <div class="content">
		<div class="container">
			
		
		
		
		
		<!------------------------------------------------------------------------------------------------------>
		
		
		
		
		
		<div class="content">
   <div class="container">
   
  
  <?php //echo $table_name; ?>
  
	
					
				<form method="get" action="sc_quiz1.php">
				
						   <a href="#" class="list-group-item list-group-item-info"><h4 ><?php echo $row['question']; ?></h4></a><br>
							
							<div  class="list-group">
							
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="A">
											<?php echo $row['opa']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="B">
											<?php echo $row['opb']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="C">
											<?php echo $row['opc']; ?>
								</a><br>
								
								<a href="#" class="list-group-item">	
										<input type="radio" name="opa" value="D">
											<?php echo $row['opd']; ?>
								</a><br>
								
							</div>
							
						
						<br>
				
					 
					 <input type="submit" class="btn btn-success" value="Next" name="sqnext">
			
				</form>
		
			 
		
			
	</div>
   </div>
		

		<!------------------------------------------------------------------------------------------------------>
	
		</div>
	</div>		
	<?php include('footer.php'); ?>