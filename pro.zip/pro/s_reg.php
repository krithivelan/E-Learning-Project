

<?php
	
	include('config.php');
	include('db.php');
	
	$login_msg='';
	
	if(isset( $_POST['rregister']))
	{
	
		$var_rname = $_POST['rname'];
		$var_rusername = $_POST['rusername'];
		$var_remail = $_POST['remail'];
		$var_rcourse = $_POST['rcourse'];
		$var_rpassword = $_POST['rpassword'];
		$var_rrepassword = $_POST['rrepassword'];
		$var_rage = $_POST['rage'];
		$var_rgender = $_POST['rgender'];
		$var_rphno = $_POST['rphno'];
		
		if(!empty($var_rname)&&!empty($var_rusername)&&!empty($var_remail)&&!empty($var_rcourse)&&!empty($var_rpassword)&&!empty($var_rrepassword)&&!empty($var_rage)&&!empty($var_rgender)&&!empty($var_rphno))
		{	
			if($var_rpassword==$var_rrepassword)
			{				
				if( strlen($var_rphno)== 10 )
				{
				
					$query = "INSERT INTO sregister(sname,susername,semail,
					scourse,spassword,sage,
					sgender,sphoneno) VALUES('$var_rname','$var_rusername','$var_remail','$var_rcourse','$var_rpassword',$var_rage,'$var_rgender','$var_rphno')";
					
					if(mysqli_query($conn,$query))
					{
						header('Location: '.ROOT_URL.'login.php?msg=<p class="alert alert-success">Successfully Registered. Login to continue...</p>');
						
					}
					else
					{
						echo 'ERROR-------------'.mysqli_error($conn);
					}				
				}
				else
				{
					$login_msg="Enter Correct Phone No ! ";
					$login_msg_class="alert-danger";
				}
				
			}
			
			else
			{				
				$login_msg = " Password and Confirm password dosen't match ! ";
				$login_msg_class = "alert-danger";		
			}
						
		}
		
		else
		{
			$login_msg = " Fill in all the fields ! ";
			$login_msg_class = "alert-danger";
			
		}	
	}
	
?>



<?php include('header.php'); ?>
<?php include('home_nav.php'); ?>
  
  <div class="container">
  
			<?php if(  $login_msg != ''  ): ?>
			
				<div class="alert <?php echo $login_msg_class; ?>"><?php echo $login_msg; ?></div>
				
			<?php endif; ?>
  
	<h1 class="login_heading">Student Registration Form</h1>
			
			
			
				<form action="register.php" method="POST">
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="rname" placeholder="Enter your Username" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>User Name</label>
						<input type="text" name="rusername" placeholder="Enter your User Name" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="remail" placeholder="Enter your Email" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Choose your Course</label>
						
						<select name="rcourse">
							
								<option value="C">C</option>
								<option value="C++">C++</option>
															
						</select>
						
					</div>
					
					
					<br>
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="rpassword" placeholder="Enter your Password" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Re-Enter Password</label>
						<input type="password" name="rrepassword" placeholder="Re-Enter your Password" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Age</label>
						<input type="number" name="rage" placeholder="Enter your Age" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Gender</label>
							<select name="rgender">
								
									<option value="Male">Male</option>
									<option value="Female">Female</option>
									<option value="Other">Other</option>
								
							</select>
					</div>
					
					<br>
					
										
					<br>
					
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" name="rphno" placeholder="Enter your Phone number" class="form-control">
					</div>
					
					<br>
					
					<p>By registering you accept our terms and conditions</p>
					
					<br>
					
					<div class="form-group">
						<input type="submit" value="Register" name="rregister" class="btn btn-primary">
					</div>
					<br><br><br><br>
						
				</form> 
  </div>
  
  
  <?php include('footer.php'); ?>