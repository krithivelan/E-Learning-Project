
<?php

    session_start();
	include('config.php');
	include('db.php');
	
	$login_msg='';
	if( filter_has_var  (INPUT_POST,'lsubmit')    )
	{
	
		$var_lname = $_POST['lname'];
		
		$var_lpassword = $_POST['lpassword'];
		
		$var_ldes = $_POST['ldes'];
		
		if(!empty($var_lname)&&!empty($var_lpassword)&&!empty($var_ldes))
		{
			
			
			if($var_ldes=="Student")
			{
				
				$query = "SELECT id,sname,susername,spassword,scourse FROM sregister WHERE susername='$var_lname' AND spassword='$var_lpassword'";
			
				$result = mysqli_query($conn,$query);
			
				if($row=mysqli_fetch_assoc($result))
				{
					
					$_SESSION['susername'] = $var_lname;
					$_SESSION['sid'] = $row['id'];
					$_SESSION['scourse'] = $row['scourse'];
					$_SESSION['sname'] = $row['sname'];
					
					header('location: '.ROOT_URL.'shome.php');
				}
				else
				{
					$login_msg = " Invalid Username and Password ! ";
					$login_msg_class = "alert-danger";
				}
				
			}
			else if($var_ldes=="Tutor")
			{
				
				$query = "SELECT tid,tusername,tpassword FROM tutor_register WHERE tusername='$var_lname' AND tpassword='$var_lpassword'";
			
				$result = mysqli_query($conn,$query);
				
				if(mysqli_fetch_assoc($result))
				{
					$_SESSION['tname'] = $var_lname;
					header('location: '.ROOT_URL.'tutor_home.php');
				}
				else
				{
					$login_msg = " Invalid Username and Password ! ";
					$login_msg_class = "alert-danger";
				}
			}
			
		}
		
		else
		{
			$login_msg = " Enter the Username and Password ! ";
			$login_msg_class = "alert-danger";
			
		}	
	}
	
?>




<?php include('header.php'); ?>	
<?php include('login_nav.php'); ?>
	
	
		<div class="container">
		
		<?php if(isset($_GET['msg'])): ?>
			
			<?php echo $_GET['msg']; ?>
			
		<?php endif; ?>
		
			
			<?php if(  $login_msg != ''  ): ?>
			
				<div class="alert <?php echo $login_msg_class; ?>"><?php echo $login_msg; ?></div>
				
			<?php endif; ?>
		
		
		
			<div class="login_class"> 
			
			<h1 class="login_heading">Login</h1>
			
			
			
				<form action="login.php" method="POST">
					<div class="form-group">
						<label>User Name</label>
						<input type="text" name="lname" placeholder="Enter your Username" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="lpassword" placeholder="Enter your Password" class="form-control">
					</div>
					
					<br>
					
					<div class="form-group">
						<label>Choose Your Designation</label>
							<select name="ldes">
								
									<option value="Student">Student</option>
									<option value="Tutor">Tutor</option>
									
							</select>
					</div>
					
					<div class="form-group">
						<input type="submit" value="Login" name="lsubmit" class="btn btn-primary">
					</div>
				</form>
			

				<h4>Click here to <a href="register.php">Register</a></h4>
				
				
			</div>
			
			
		</div>
		
<?php include('footer.php'); ?>

	