
 <?php 

	session_start();
	include('config.php');
	include('db.php');
	include('db2_config.php');
	$username = $_SESSION['tname'];
	
	if(!isset($_SESSION['tname']))
	{
		header('location: '.ROOT_URL.'login.php?msg=<p class="alert alert-danger">Login to get Access ! </p>');
	}

?>
  
   <?php include('header.php'); ?>
   <?php include('tutor_login_nav.php'); ?>
   
   <div class="container">
   
    
   
   
   <h4 style="
		float:right;
		background-color:MediumSeaGreen;
		padding:15px;
		color:white;
		display:inline-block;
		text-align:center;"
			
		>Welcome <?php echo $_SESSION['tname']; ?></h4>
		
		
		
		<!--
		
		<form action="tutor_home.php" method="post" enctype="multipart/form-data">
			<input type="file" name="file" />
			<br>
			<button type="submit" name="btn-upload">upload</button>
		</form>
		
		
		-->
		
		
		
		<div id="header">
			
				</div>
					<div id="body">
					
					
					 
						<br /><br />
						<?php
							 if(isset($_GET['success']))
							 {
									?>
									<label>File Uploaded Successfully...  <a href="view.php">click here to view file.</a></label><br><br>
									<?php
							 }
							 else if(isset($_GET['fail']))
							 {
									?>
									<label>Problem While File Uploading !</label><br><br>
									<?php
							 }
							 else
							 {
									?>
									<h4><label>Uploaded files ( PDF, DOC, EXE, VIDEO, MP3, ZIP,etc...)</label></h4><br><br>
									<?php
							 }
					 ?>
				</div>
			<div id="footer">
			
		</div>
					
		
		<!-- UPLOAD CONTENT -->
		
		<?php
		
			if(isset($_POST['btn-upload']))
			{    
				 
			 $file = $_FILES['file']['name'];
			 $file_loc = $_FILES['file']['tmp_name'];
			 $file_size = $_FILES['file']['size'];
			 $file_type = $_FILES['file']['type'];
			 $folder="uploads/";
			 
			 move_uploaded_file($file_loc,$folder.$file);
			 $sql="INSERT INTO tbl_uploads(file,type,size) VALUES('$file','$file_type','$file_size')";
			 mysqli_query($conn_db,$sql); 
			}
		
			
		?>
		
		<!-- DISPLAY CONTENT -->
		<div class="panel panel-default">
			<div class="panel-heading">C Programming<br></div>
			
				
					<table class="table table-default" width="100%" >
								
								<tr >
									<td class="class_files"><strong>File Name</strong></td>							
									<td class="class_files"><strong>Download</strong></td>
									<td class="class_files"><strong>Heading</strong></td>
									<td class="class_files"><strong>Content</strong></td>
								</tr>
								
								
								<?php
									 
									 $sql="SELECT * FROM c_table";
									 
									 $result_set=mysqli_query($conn,$sql);
									 while($row=mysqli_fetch_assoc($result_set))
									 {
								?>
								
									
									<tr >
									
									<td ><?php echo $row['file'] ?></td>
									
									<td ><a href="uploads/<?php echo $row['file'] ?>" 
									target="_blank" class="btn btn-success">Download</a></td>
									
									<td ><?php echo $row['heading'] ?></td>
									<td ><?php echo $row['content'] ?></td>
									
									</tr>
									
									
									
								<?php }	 ?>
					</table>
				
			
			</div>
			
			
			<br><br>
			
			
			<div class="panel panel-default">
			<div class="panel-heading">C++ Programming<br></div>
			
				<div >
					<table class="table table-default" width="100%" >
						
						<tr >
							<td class="class_files"><strong>File Name</strong></td>							
							<td class="class_files"><strong>Download</strong></td>
							<td class="class_files"><strong>Heading</strong></td>
							<td class="class_files"><strong>Content</strong></td>
						</tr>
						
						
						<?php
							 
							 $sql="SELECT * FROM cplus_table";
							 
							 $result_set=mysqli_query($conn,$sql);
							 while($row=mysqli_fetch_assoc($result_set))
							 {
						?>
						
							<tr >
							
							<td class="class_files"><?php echo $row['file'] ?></td>
							
							<td class="class_files"><a href="uploads/<?php echo $row['file'] ?>" 
							target="_blank" class="btn btn-success">Download</a></td>
							
							<td class="class_files"><?php echo $row['heading'] ?></td>
							<td class="class_files"><?php echo $row['content'] ?></td>
							
							</tr>
							
						<?php }	 ?>
			</table>
				</div>
			</div>
			
			
			
			<br><br>
			
			<div class="panel panel-default">
			<div class="panel-heading">Announcements<br></div>
				<?php
							 
						$sql="SELECT * FROM t_ann WHERE name='$username'; ";
							 
						$result_set=mysqli_query($conn,$sql);
						while($row=mysqli_fetch_assoc($result_set))
							 {
								 
						//print_r($row);
				?>
					
							<h4 ><strong> Course : <?php echo $row['course']; ?></strong></h4>
							<p > Posted at : <?php echo $row['time']; ?></p>
							<h4 ><?php echo $row['ann']; ?></h4>
						
				<?php }	 ?>
			
			
			
			
			
			<?php
			
			/*
			$sql="SELECT * FROM tbl_uploads";
			 $result_set=mysqli_query($conn_db,$sql);
			 while($row=mysqli_fetch_assoc($result_set))
			 {
				 
			*/
			  ?>
					
					
			<!--		
					
					<div class="row">
					  <div class="col-sm-6 col-md-4">
						<div class="thumbnail">
						  <div class="glyphicon glyphicon-file" >
						  <div class="caption">
							<h3><?php //echo $row['file'] ?></h3>
							
							<p><a href="uploads/<?php //echo $row['file'] ?>" target="_blank"  class="btn btn-success">Download</a> 
							<a href="#" class="btn btn-danger" class="glyphicon glyphicon-trash" >Delete</a></p>
						  </div>
						  </div>
						</div>
					  </div>
					</div>
							
					
					<br>
					
			<?php // } ?>
			
			-->
			
			
			
			<?php
			/*
			 $sql="SELECT * FROM tbl_uploads";
			 $result_set=mysqli_query($conn_db,$sql);
			 while($row=mysqli_fetch_assoc($result_set))
			 {
			
			*/
			  ?>
			  
			  
				
			<!--  
			
			
					<div class="panel panel-default">
						  
						  
						  <div class="panel-heading">Panel heading</div>
						  <div class="panel-body">
							<p>Panel body content and elements of or about the content uploaded</p>
						  </div>
						  
						  

						  
						  <ul class="list-group">
							<div class="list-group" ><?php //echo "File Name : ";echo $row['file']; ?></div>
							<a href="uploads/<?php //echo $row['file'] ?>" target="_blank" class="btn btn-success" >Download</a>
						  </ul>
					</div>
					
					<br>
					
					       
			
			<?php	// }	 ?>
			
			
			-->
		<br><br>
		</div>
   </div>
   
   <?php include('footer.php'); ?>