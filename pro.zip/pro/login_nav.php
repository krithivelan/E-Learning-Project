	
	
	<div class="navbar navbar-default">
				<div class="navbar-header">
					
						<div class="navbar-brand" class="nav_title"><a href="login.php"><strong>E-Learning</strong></a></div>
						
						<ol>
							
							
							<li ><a href="courses.php">Courses</a></li>
							<li ><a href="register.php">Register</a></li>
							<li ><a href="contactus.php">Contact Us</a></li>
							
						</ol>
						</div>
			
										
			</div>
			
		<br>