
  <?php 

  include('config.php');
  include('db.php');
  session_start();
  session_destroy();
  header('location: '.ROOT_URL.'login.php');

  ?>