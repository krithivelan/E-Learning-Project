
  <?php include('header.php'); ?>
  <?php include('home_nav.php'); ?>
  
  <div class="container">
		
		
		<div class="course_class">C Programming<br><br><a href="register.php" class="btn btn-primary">Register</a></div>
		<div class="course_class">C++ Pogramming<br><br><a href="register.php" class="btn btn-primary">Register</a></div>
		<div class="course_class">Java Pogramming<br><br><a href="register.php" class="btn btn-primary">Register</a></div>
		<div class="course_class">HTML<br><br><a href="register.php" class="btn btn-primary">Register</a></div>
		<div class="course_class">CSS<br><br><a href="register.php" class="btn btn-primary">Register</a></div>
		
  
  </div>
  
  
  
  <?php include('footer.php'); ?>
  