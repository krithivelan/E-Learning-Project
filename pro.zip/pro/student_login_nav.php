
  <div class="navbar navbar-default">
	 
		<div class="navbar-header">
					
			<div class="navbar-brand" class="nav_title"><a href="shome.php"><strong>E-Learning</strong></a>
				
			</div>						
				<ol>
					<li ><a href="s_pro.php">Profile</a></li>
					<li ><a href="s_ann.php">Announcements</a></li>
					<li ><a href="s_cou.php">My Courses</a></li>
					<li ><a href="s_quiz.php">Quiz</a></li>
				</ol>
		</div>
			
		<li class="login_disp"><a href="logout.php">Logout</a></li>
				
				
	</div>
	
	
	<br>